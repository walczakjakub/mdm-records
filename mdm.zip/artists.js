const wiked = {
  name: "Wiked",
  photo: "img/artist-profiles/wiked.png",
  spotify: "https://open.spotify.com/artist/1F0tFgHafshRmaZUXROUCg?si=_qO6S4d3QTOzWHYqjAA1Pw",
  soundcloud: "https://soundcloud.com/ogwiked",
  apple: "https://music.apple.com/us/artist/wiked/1511344353"
}

const lilCap = {
  name: "Lil Cap",
  photo: "img/artist-profiles/wiked.png",
  spotify: "https://open.spotify.com/artist/7sEq6DRIZq9lR8Vw21rzAj?si=2NbtenK5QJGid-pB3gnVLw",
  soundcloud: "https://soundcloud.com/jandlmusic",
  apple: "https://music.apple.com/us/artist/lil-cap/1641913172"
}

const mollyRollin = {
  name: "Molly Rollin",
  photo: "img/artist-profiles/wiked.png",
  spotify: "https://open.spotify.com/artist/5nHZ49Alq60QDOhyfslJ5t?si=ZiQcE-OlRbKO-lW6Edu7vg ",
  soundcloud: "https://soundcloud.com/molly-rollin ",
  apple: "https://music.apple.com/us/artist/molly-rollin/1581282595"
}

const sparkyKNE = {
  name: "SparkyKNE",
  photo: "img/artist-profiles/wiked.png",
  spotify: "https://open.spotify.com/artist/0L5sXPK5fHlRUMCMEtYCnl?si=lgKBWVI5RfKSbP8KBIRJFg ",
  soundcloud: "https://soundcloud.com/s_kane ",
  apple: "https://music.apple.com/us/artist/sparkykne/1606462223"
}

const cocaineCowboy = {
  name: "Cocaine Cowboy",
  photo: "img/artist-profiles/wiked.png",
  spotify: "https://open.spotify.com/artist/3ujovs8b760r4zphd8Lv33?si=4Hki9l7VSiiJ2Xz3W1nDYw ",
  soundcloud: "https://soundcloud.com/theyoungramen ",
  apple: "index.html"
}

const saintBalenci = {
  name: "Saint Balenci",
  photo: "img/artist-profiles/wiked.png",
  spotify: "https://open.spotify.com/artist/2BBkT5XeK48RN0sYtPWxTj?si=UQw8BtHQTKOJ88D64ZNoWQ ",
  soundcloud: "https://soundcloud.com/saintbalenci ",
  apple: "https://music.apple.com/us/artist/saint-balenci/1502017319"
}

const bigToe = {
  name: "Big Toe",
  photo: "img/artist-profiles/wiked.png",
  spotify: "https://open.spotify.com/artist/29znzvIHLUmUVwvpTR7jiW?si=9e1tcVt9QyCfSNZ_X9j12Q ",
  soundcloud: "https://soundcloud.com/bigtoee ",
  apple: "https://music.apple.com/us/artist/big-toe/1600609703"
}

const blackNWhite = {
  name: "Black N White",
  photo: "img/artist-profiles/wiked.png",
  spotify: "https://open.spotify.com/artist/1lQGjoQVhXmcQQGhTJ9kY7?si=_r9y5IqPSp2O220hRlw-sw ",
  soundcloud: "https://soundcloud.com/user-412375318",
  apple: "https://music.apple.com/us/artist/black-n-white/1601463994"
}

const jarne = {
  name: "Jarne",
  photo: "img/artist-profiles/wiked.png",
  spotify: "https://open.spotify.com/artist/0URorlXhGW8MPppdYxIJi1?si=9GbO0J40QVq3aZF043oj-A",
  soundcloud: "index.html",
  apple: "https://music.apple.com/us/artist/jarne/1503614068"
}

const jakeUp = {
  name: "Jake Up",
  photo: "img/artist-profiles/wiked.png",
  spotify: "https://open.spotify.com/artist/0Bnhk31LFmf9hHdedMbZBe?si=G6NJObeCRzKEVJzrq3maxQ",
  soundcloud: "https://soundcloud.com/jakeuppo ",
  apple: "index.html"
}

const eliPorter = {
  name: "Eli Porter",
  photo: "img/artist-profiles/wiked.png",
  spotify: "https://open.spotify.com/artist/1X62wOavcIkoW1V4Ncl7KA?si=R-cv557KQSmK2xsBUwUHig",
  soundcloud: "https://soundcloud.com/klutch7",
  apple: "https://music.apple.com/us/artist/eli-porter/1640926633"
}

const aubreyAdams = {
  name: "Aubrey Adams",
  photo: "img/artist-profiles/wiked.png",
  spotify: "https://open.spotify.com/artist/6zqRYMLtSo2QLYI5BYFcOb?si=r6KwcuxPRV2cvvI2R5ORlQ ",
  soundcloud: "https://soundcloud.com/aubrey_adams ",
  apple: "index.html"
}

const tonyGarcia = {
  name: "Tony Garcea",
  photo: "img/artist-profiles/wiked.png",
  spotify: "https://open.spotify.com/artist/48GbE6nNzILnFoFoloBQcv?si=gsHIEzGORgSAJ8dn3l-3IQ ",
  soundcloud: "https://soundcloud.com/tony-garcea",
  apple: "https://music.apple.com/us/artist/tony-garcea/1642988248"
}

const raidenRufio = {
  name: "Raiden Rufio",
  photo: "img/artist-profiles/wiked.png",
  spotify: "https://open.spotify.com/artist/4f4MVvA5mzebX3ONA92ksI?si=-ZoA9DD4RLC-89YS7d1vhQ ",
  soundcloud: "https://soundcloud.com/raiden-rufio ",
  apple: "https://music.apple.com/us/artist/raiden-rufio/1641632916"
}

const aliceHefner = {
  name: "Alice Hefner",
  photo: "img/artist-profiles/wiked.png",
  spotify: "https://open.spotify.com/artist/0MfO3P82eA1g9z8u7r4BTq?si=Yk908pUyTcWPjjeB4YFLDQ ",
  soundcloud: "https://soundcloud.com/alicehefner",
  apple: "https://music.apple.com/us/artist/alice-hefner/1643745023"
}

const harlowAustin = {
  name: "Harlow Austin",
  photo: "img/artist-profiles/wiked.png",
  spotify: "https://open.spotify.com/artist/2Er6Ck52DqfM4yScqFvI5e?si=awaQzNGNSlSnPMfbvRssOg ",
  soundcloud: "https://soundcloud.com/harlowmdmr",
  apple: "index.html"
}

const z3d = {
  name: "Z3D",
  photo: "img/artist-profiles/wiked.png",
  spotify: "index.html",
  soundcloud: "https://soundcloud.com/user-295188554",
  apple: "index.html"
}

const lukeD = {
  name: "Luke D",
  photo: "img/artist-profiles/wiked.png",
  spotify: "https://open.spotify.com/artist/6uUTZYMP8cMef15wLLtqtL",
  soundcloud: "https://soundcloud.com/bskluked",
  apple: "index.html"
}

const ljHuncho = {
  name: "LJhuncho",
  photo: "img/artist-profiles/wiked.png",
  spotify: "https://open.spotify.com/artist/16ouyXVht086EhrTc3NFuc?si=YPZ1UHHERASzi8wd1yVTZw ",
  soundcloud: "https://soundcloud.com/ljhuncho ",
  apple: "https://music.apple.com/us/artist/ljhuncho/1451621321"
}

const brisBane = {
  name: "Bris Bane",
  photo: "img/artist-profiles/wiked.png",
  spotify: "https://open.spotify.com/artist/14ZLMbJmQj6H1I3KZp36ov?si=M5EBgpiYRbCH36KvGULRpw",
  soundcloud: "https://on.soundcloud.com/kAUh4",
  apple: "https://music.apple.com/us/artist/bris-bane/1625923792"
}

const klaas2 = {
  name: "Klaas2",
  photo: "img/artist-profiles/klaas2.png",
  spotify: "https://open.spotify.com/artist/1uiS4TmylmCodKUD2pEBfx?si=c4bFpQrLTq-yOEPCgSDY3g",
  soundcloud: "https://soundcloud.com/klaas-nowak",
  apple: "https://music.apple.com/us/artist/klaas2/1640577098"
}

const font = {
  name: "Font",
  photo: "img/artist-profiles/wiked.png",
  spotify: "https://open.spotify.com/artist/3Kfoq3RzS4K92yaSXpFcNC?si=eGC5Jo-GTQuZR0Hd3ubRCA",
  soundcloud: "index.html",
  apple: "https://music.apple.com/gb/artist/font/1581669741"
}

const patywp = {
  name: "Patywp",
  photo: "img/artist-profiles/wiked.png",
  spotify: "https://open.spotify.com/artist/2EbRvAS5CxK76lpNQJ8Vxw?si=bDTrPb17T_u3rOWeIC3kHQ",
  soundcloud: "https://soundcloud.com/patywp-694872646 ",
  apple: "https://music.apple.com/us/artist/patywp/1639526132"
}

const luissssa = {
  name: "Luissssa",
  photo: "img/artist-profiles/wiked.png",
  spotify: "https://open.spotify.com/artist/1F5y0XTR5n4oPX8rDvoAxJ?si=UwrQ7Oo9RJKc_f01fExQVA ",
  soundcloud: "https://soundcloud.com/luissssa ",
  apple: "https://music.apple.com/us/artist/luissssa/1646514672"
}

const kalera = {
  name: "Kalera",
  photo: "img/artist-profiles/wiked.png",
  spotify: "https://open.spotify.com/artist/3AU2RCh3OsWdsSyGdKMy17?si=IPzgZY7QRFeZ1xeTwg-Z2A ",
  soundcloud: "index.html",
  apple: "index.html"
}
